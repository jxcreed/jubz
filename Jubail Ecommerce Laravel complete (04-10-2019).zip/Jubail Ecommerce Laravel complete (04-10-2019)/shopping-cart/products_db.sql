-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2019 at 04:33 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `products_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_04_09_145313_create_products_table', 1),
(2, '2019_04_09_161039_create_user_table', 1),
(3, '2019_04_10_084041_create_orders_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `cart` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `created_at`, `updated_at`, `user_id`, `cart`, `address`, `name`, `payment_id`) VALUES
(1, '2019-04-10 06:30:55', '2019-04-10 06:30:55', 1, 'O:8:\"App\\Cart\":3:{s:5:\"items\";a:2:{i:1;a:3:{s:3:\"qty\";i:1;s:5:\"price\";i:52;s:4:\"item\";O:11:\"App\\Product\":26:{s:11:\"\0*\0fillable\";a:4:{i:0;s:9:\"imagePath\";i:1;s:5:\"title\";i:2;s:11:\"description\";i:3;s:5:\"price\";}s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:8:\"products\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:13:\"\0*\0attributes\";a:7:{s:2:\"id\";i:1;s:10:\"created_at\";s:19:\"2019-04-10 14:11:52\";s:10:\"updated_at\";s:19:\"2019-04-10 14:11:52\";s:9:\"imagePath\";s:106:\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQMyZe2DB_9VxrPeyaa5lRsK7P-Hi_7saEO99t0Y2mObQK1vr3dmw\";s:5:\"title\";s:11:\"Red T-Shirt\";s:11:\"description\";s:16:\"Red Cool T-shirt\";s:5:\"price\";i:52;}s:11:\"\0*\0original\";a:7:{s:2:\"id\";i:1;s:10:\"created_at\";s:19:\"2019-04-10 14:11:52\";s:10:\"updated_at\";s:19:\"2019-04-10 14:11:52\";s:9:\"imagePath\";s:106:\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQMyZe2DB_9VxrPeyaa5lRsK7P-Hi_7saEO99t0Y2mObQK1vr3dmw\";s:5:\"title\";s:11:\"Red T-Shirt\";s:11:\"description\";s:16:\"Red Cool T-shirt\";s:5:\"price\";i:52;}s:10:\"\0*\0changes\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:8:\"\0*\0dates\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:10:\"timestamps\";b:1;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}i:2;a:3:{s:3:\"qty\";i:1;s:5:\"price\";i:60;s:4:\"item\";O:11:\"App\\Product\":26:{s:11:\"\0*\0fillable\";a:4:{i:0;s:9:\"imagePath\";i:1;s:5:\"title\";i:2;s:11:\"description\";i:3;s:5:\"price\";}s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:8:\"products\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:13:\"\0*\0attributes\";a:7:{s:2:\"id\";i:2;s:10:\"created_at\";s:19:\"2019-04-10 14:11:52\";s:10:\"updated_at\";s:19:\"2019-04-10 14:11:52\";s:9:\"imagePath\";s:104:\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJe4vdxvTC8GdzateU1tmY342JOL81H4-PKsm8eRyLtXzApnqm\";s:5:\"title\";s:12:\"Blue T-Shirt\";s:11:\"description\";s:17:\"Blue Cool T-shirt\";s:5:\"price\";i:60;}s:11:\"\0*\0original\";a:7:{s:2:\"id\";i:2;s:10:\"created_at\";s:19:\"2019-04-10 14:11:52\";s:10:\"updated_at\";s:19:\"2019-04-10 14:11:52\";s:9:\"imagePath\";s:104:\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJe4vdxvTC8GdzateU1tmY342JOL81H4-PKsm8eRyLtXzApnqm\";s:5:\"title\";s:12:\"Blue T-Shirt\";s:11:\"description\";s:17:\"Blue Cool T-shirt\";s:5:\"price\";i:60;}s:10:\"\0*\0changes\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:8:\"\0*\0dates\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:10:\"timestamps\";b:1;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}}s:8:\"totalQty\";i:2;s:10:\"totalPrice\";i:112;}', 'Malate', 'Rudolfo Jubail M. Salamida', 'ch_1ENhRzC9sggvw2S7RiF4Th93'),
(2, '2019-04-10 06:31:33', '2019-04-10 06:31:33', 1, 'O:8:\"App\\Cart\":3:{s:5:\"items\";a:2:{i:2;a:3:{s:3:\"qty\";i:2;s:5:\"price\";i:120;s:4:\"item\";O:11:\"App\\Product\":26:{s:11:\"\0*\0fillable\";a:4:{i:0;s:9:\"imagePath\";i:1;s:5:\"title\";i:2;s:11:\"description\";i:3;s:5:\"price\";}s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:8:\"products\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:13:\"\0*\0attributes\";a:7:{s:2:\"id\";i:2;s:10:\"created_at\";s:19:\"2019-04-10 14:29:25\";s:10:\"updated_at\";s:19:\"2019-04-10 14:29:25\";s:9:\"imagePath\";s:104:\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJe4vdxvTC8GdzateU1tmY342JOL81H4-PKsm8eRyLtXzApnqm\";s:5:\"title\";s:12:\"Blue T-Shirt\";s:11:\"description\";s:17:\"Blue Cool T-shirt\";s:5:\"price\";i:60;}s:11:\"\0*\0original\";a:7:{s:2:\"id\";i:2;s:10:\"created_at\";s:19:\"2019-04-10 14:29:25\";s:10:\"updated_at\";s:19:\"2019-04-10 14:29:25\";s:9:\"imagePath\";s:104:\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJe4vdxvTC8GdzateU1tmY342JOL81H4-PKsm8eRyLtXzApnqm\";s:5:\"title\";s:12:\"Blue T-Shirt\";s:11:\"description\";s:17:\"Blue Cool T-shirt\";s:5:\"price\";i:60;}s:10:\"\0*\0changes\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:8:\"\0*\0dates\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:10:\"timestamps\";b:1;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}i:3;a:3:{s:3:\"qty\";i:1;s:5:\"price\";i:100;s:4:\"item\";O:11:\"App\\Product\":26:{s:11:\"\0*\0fillable\";a:4:{i:0;s:9:\"imagePath\";i:1;s:5:\"title\";i:2;s:11:\"description\";i:3;s:5:\"price\";}s:13:\"\0*\0connection\";s:5:\"mysql\";s:8:\"\0*\0table\";s:8:\"products\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:13:\"\0*\0attributes\";a:7:{s:2:\"id\";i:3;s:10:\"created_at\";s:19:\"2019-04-10 14:29:25\";s:10:\"updated_at\";s:19:\"2019-04-10 14:29:25\";s:9:\"imagePath\";s:104:\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ7YB9Gp32PrkJG_OtO8Q3CDUOyiIEHh6nkuhmxWzkl6KiX6t28\";s:5:\"title\";s:20:\"Yellow Green T-Shirt\";s:11:\"description\";s:25:\"Yellow Green Cool T-shirt\";s:5:\"price\";i:100;}s:11:\"\0*\0original\";a:7:{s:2:\"id\";i:3;s:10:\"created_at\";s:19:\"2019-04-10 14:29:25\";s:10:\"updated_at\";s:19:\"2019-04-10 14:29:25\";s:9:\"imagePath\";s:104:\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ7YB9Gp32PrkJG_OtO8Q3CDUOyiIEHh6nkuhmxWzkl6KiX6t28\";s:5:\"title\";s:20:\"Yellow Green T-Shirt\";s:11:\"description\";s:25:\"Yellow Green Cool T-shirt\";s:5:\"price\";i:100;}s:10:\"\0*\0changes\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:8:\"\0*\0dates\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:10:\"timestamps\";b:1;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}}s:8:\"totalQty\";i:3;s:10:\"totalPrice\";i:220;}', 'Malate', 'Rudolfo Jubail M. Salamida', 'ch_1ENhSaC9sggvw2S7ou1BKSfG');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `imagePath` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `created_at`, `updated_at`, `imagePath`, `title`, `description`, `price`) VALUES
(1, '2019-04-10 06:29:25', '2019-04-10 06:29:25', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQMyZe2DB_9VxrPeyaa5lRsK7P-Hi_7saEO99t0Y2mObQK1vr3dmw', 'Red T-Shirt', 'Red Cool T-shirt', 54),
(2, '2019-04-10 06:29:25', '2019-04-10 06:29:25', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJe4vdxvTC8GdzateU1tmY342JOL81H4-PKsm8eRyLtXzApnqm', 'Blue T-Shirt', 'Blue Cool T-shirt', 60),
(3, '2019-04-10 06:29:25', '2019-04-10 06:29:25', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ7YB9Gp32PrkJG_OtO8Q3CDUOyiIEHh6nkuhmxWzkl6KiX6t28', 'Yellow Green T-Shirt', 'Yellow Green Cool T-shirt', 100),
(4, '2019-04-10 06:29:25', '2019-04-10 06:29:25', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQB3gUvvi2K81U99uVKdjGMIurqeMThv4B4EXH-sP_Fu-Ehe4jEXg', 'White T-Shirt', 'White Cool T-shirt', 95),
(5, '2019-04-10 06:29:25', '2019-04-10 06:29:25', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRRY2FFiH4tIX-H3457lbMDhYcpHcF34nEM1UltcFkBwt9e7Ox4Zg', 'Grey T-Shirt', 'Grey Cool T-shirt', 70),
(6, '2019-04-10 06:29:25', '2019-04-10 06:29:25', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRL5z8MeX1XcYoEBSumvBdx2iu8LT6FmZ7Z55Vd9DPKJTyj4Vu0', 'Brown T-Shirt', 'Brown Cool T-shirt', 68);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `created_at`, `updated_at`, `name`, `email`, `password`, `provider_id`, `remember_token`) VALUES
(1, '2019-04-10 06:29:55', '2019-04-10 06:29:55', NULL, 'jxcreed17@yahoo.com', '$2y$10$5XPjxdYeaLdPjNKSY.XUo.32RhdmUa7BhRPbz1I5n9oZQWg5QGAVS', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
