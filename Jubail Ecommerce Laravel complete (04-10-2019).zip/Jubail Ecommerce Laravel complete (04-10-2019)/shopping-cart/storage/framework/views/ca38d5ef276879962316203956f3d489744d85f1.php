<?php $__env->startSection('content'); ?>
		<div class="row">
			<div class="col-md-4 col-md-offset-4">
				<h1>Successfully Purchased</h1>
			</div>
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>