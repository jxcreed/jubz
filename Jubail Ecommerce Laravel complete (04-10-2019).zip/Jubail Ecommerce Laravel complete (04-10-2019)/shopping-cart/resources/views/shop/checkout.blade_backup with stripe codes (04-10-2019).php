@extends('layouts.master')

@section('title')
	Laravel Shopping Cart
@endsection

@section('content')
	<div class="row">
		<div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
			<h1>Checkout</h1>
			<h3>Payment Form</h3>
			@if(Session::has('success_message'))
				<div class="alert alert-info">{{ Session::has('success_message') }}</div>
			@endif
			<form action="{{ route('checkout') }}" method="post" id="payment-form">
			 
			  <div class="form-group">
			  	<label>Email</label>
			  	<input type="email" id="email" name="email" value="jxcreed17@yahoo.com" class="form-control" readonly/>
			  </div>
			  <div class="form-group">
			  	<label>Name</label>
			  	<input type="text" id="name" name="name" value="Rudolfo Jubail M. Salamida" class="form-control" readonly/>
			  </div>

			  <div class="form-row">
			  	<div class="form-group col-md-6">
			  		<label>Address</label>
			  		<input type="text" id="address" name="address" class="form-control"/>
			  	</div>
			  	<div class="form-group col-md-3">
			  		<label>City</label>
			  		<input type="text" id="city" name="city" class="form-control"/>
			  	</div>
			  	<div class="form-group col-md-3">
			  		<label>State</label>
			  		<input type="text" id="state" name="state" class="form-control"/>
			  	</div>
			  </div>

			  <div class="form-row">
			  	<div class="form-group col-md-4">
			  		<label>Country</label>
			  		<input type="text" id="country" name="country" class="form-control"/>
			  	</div>
			  	<div class="form-group col-md-5">
			  		<label>Phone</label>
			  		<input type="text" id="phone" name="phone" class="form-control"/>
			  	</div>
			  	<div class="form-group col-md-3">
			  		<label>Total</label>
			  		<input type="text" id="total" name="total" value="${{ $total }}" class="form-control" readonly/>
			  		{{csrf_field()}}
			  	</div>
			  </div>

			  <div class="form-group">
			    <label for="card-element">
			      Credit or debit card
			    </label>
			    <div id="card-element">
			      <!-- A Stripe Element will be inserted here. -->
			    </div>

			    <!-- Used to display form errors. -->
			    <div id="card-errors" role="alert"></div>
			  </div>


			  <button class="btn btn-primary">Submit Payment</button>
			</form>
						
		</div>
	</div>

@endsection

@section('scripts')
<script type="text/javascript" src="{{ URL::to('js/checkout.js') }}"></script>
@endsection

