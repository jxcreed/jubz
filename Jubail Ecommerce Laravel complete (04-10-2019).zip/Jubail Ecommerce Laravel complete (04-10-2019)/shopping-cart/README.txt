Instruction:

1. Please install this in your htdocs folder.
   Ex: c:/xampp/htdocs/shopping-cart

2. Import the database(--products_db.sql located inside this folder) in your mysql phpmyadmin.

3. You can run the e-commerce website using this url:

   http://localhost/shopping-cart/public/
   or
   using the command 'php artisan serve' in your command prompt terminal
   
   http://127.0.0.1:8000


