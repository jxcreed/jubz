<?php

use Illuminate\Database\Seeder;

class ProductTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $product = new \App\Product([
        	'imagePath' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQMyZe2DB_9VxrPeyaa5lRsK7P-Hi_7saEO99t0Y2mObQK1vr3dmw',
        	'title' => 'Red T-Shirt',
        	'description' => 'Red Cool T-shirt',
        	'price' => 54
        ]);

        $product->save();

        $product = new \App\Product([
        	'imagePath' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJe4vdxvTC8GdzateU1tmY342JOL81H4-PKsm8eRyLtXzApnqm',
        	'title' => 'Blue T-Shirt',
        	'description' => 'Blue Cool T-shirt',
        	'price' => 60
        ]);

        $product->save();

        $product = new \App\Product([
        	'imagePath' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ7YB9Gp32PrkJG_OtO8Q3CDUOyiIEHh6nkuhmxWzkl6KiX6t28',
        	'title' => 'Yellow Green T-Shirt',
        	'description' => 'Yellow Green Cool T-shirt',
        	'price' => 100
        ]);

        $product->save();

        $product = new \App\Product([
        	'imagePath' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQB3gUvvi2K81U99uVKdjGMIurqeMThv4B4EXH-sP_Fu-Ehe4jEXg',
        	'title' => 'White T-Shirt',
        	'description' => 'White Cool T-shirt',
        	'price' => 95
        ]);

        $product->save();


        $product = new \App\Product([
        	'imagePath' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRRY2FFiH4tIX-H3457lbMDhYcpHcF34nEM1UltcFkBwt9e7Ox4Zg',
        	'title' => 'Grey T-Shirt',
        	'description' => 'Grey Cool T-shirt',
        	'price' => 70
        ]);

        $product->save();

        $product = new \App\Product([
        	'imagePath' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRL5z8MeX1XcYoEBSumvBdx2iu8LT6FmZ7Z55Vd9DPKJTyj4Vu0',
        	'title' => 'Brown T-Shirt',
        	'description' => 'Brown Cool T-shirt',
        	'price' => 68
        ]);

        $product->save();
    }
}
